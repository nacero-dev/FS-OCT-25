mult=100*100
console.log(mult);