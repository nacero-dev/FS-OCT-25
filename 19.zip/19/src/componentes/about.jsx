export default function About() {
  return <h2>About Page</h2>;
}
