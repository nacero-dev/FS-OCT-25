import GaleriaPokemon from "./componentes/galeria-pokemon";
import "./App.css";

function App() {
  return (
    <div className="contenedor-vista">
      <h1>Galeria de Pokemones</h1>
      <GaleriaPokemon />
    </div>
  );
}

export default App;
