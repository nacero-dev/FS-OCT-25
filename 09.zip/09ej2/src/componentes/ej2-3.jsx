import React from "react";
import "./ej2-3.css";

function Avatar({ url }) {
    return <img className="avatar" src={url} />;
}

export default Avatar;
