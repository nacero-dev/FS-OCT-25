const str = 'Hola como estas ?';

const words = str.split(' '); /*espacio para palabras*/

console.log(words);



