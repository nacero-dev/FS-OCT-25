/* 

chalk:  para colorear texto en la terminal, ampliamente usada.
Por ejemplo, chalk es muy usada para dar estilo (color, negrita, subrayado) a salidas en consola, especialmente en CLI tools.

*/