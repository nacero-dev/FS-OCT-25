const clc = require('cli-color');

console.log(clc.green('Esto es un log de éxito'));
console.log(clc.yellow('Esto es una advertencia'));
console.log(clc.red('Esto es un error'));


