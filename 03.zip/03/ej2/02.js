let numeros=[1,2,3,4,5,6,7,8,9,10];

feliz = numeros.map( cadanumero => cadanumero + ' :)' )

console.log(feliz);

