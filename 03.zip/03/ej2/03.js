let numeros=['1 casa','2 perro','3 lapiz'];

finder = numeros.find( cadanumero => cadanumero.includes('casa'))

console.log(finder);
