let hogwarts = [ 'Harry' , 'Potter', 'Griffindor'];

let [nombre, apellido, casa ] = hogwarts

console.log(nombre);

console.log(apellido);

console.log(casa);