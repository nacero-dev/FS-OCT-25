const frutas = ['manzana', 'banana', 'naranja'];
const vegetales = ['zanahoria', 'brócoli'];

const comida = [...frutas, ...vegetales];

console.log(comida);
